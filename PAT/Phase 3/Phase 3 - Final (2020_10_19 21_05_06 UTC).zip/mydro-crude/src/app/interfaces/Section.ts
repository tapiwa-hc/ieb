export interface SectionInfo {
  id: number;
  name: string;
}
