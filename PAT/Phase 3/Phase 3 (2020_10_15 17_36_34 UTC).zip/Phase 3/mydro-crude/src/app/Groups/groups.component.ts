import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { GroupList, NewGroup } from '../interfaces/Groups';
import { SectionInfo } from '../interfaces/Section';
import { NoticeService } from '../notice.service';

@Component({
  selector: 'app-groups',
  templateUrl: './groups.component.html',
  styleUrls: ['./groups.component.css'],
})
export class GroupsComponent implements OnInit {
  sectionInfo: SectionInfo[];
  groupList: GroupList[];
  formModel = new NewGroup(null, '');
  formVisible = false;

  constructor(
    private noticeService: NoticeService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.getSections();
    this.getGroups();
  }

  private getSections(): void {
    this.route.data.subscribe((data: { sectionInfo: SectionInfo[] }) => {
      this.sectionInfo = data.sectionInfo;
    });
  }
  private getGroups(): void {
    this.route.data.subscribe((data: { groupList: GroupList[] }) => {
      this.groupList = data.groupList;
    });
  }
  removeFromList(id) {
    this.groupList.forEach((section) => {
      section.groups = section.groups.filter((group) => group.id !== id);
    });
    this.groupList = this.groupList.filter(
      (section) => section.groups.length !== 0
    );
  }
  toggleFormVisibility() {
    this.formVisible = !this.formVisible;
  }

  clearForm() {
    this.formModel = new NewGroup(0, '');
  }
  onSubmit() {
    this.noticeService.addGroup(this.formModel).subscribe((res) => {
      this.getGroups();
      this.clearForm();
      this.toggleFormVisibility();
    });
  }
}
