import { MarkedPipe } from './marked.pipe';

describe('MarkedPipe', () => {
  it('create an instance', () => {
    const pipe = new MarkedPipe();
    expect(pipe).toBeTruthy();
  });
});
