import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-groups-dialog',
  templateUrl: './groups-dialog.component.html',
})
export class GroupsDialogComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
